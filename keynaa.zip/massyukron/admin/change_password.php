<?php
session_start();
require_once '../config/database.php';

// Require login
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit();
}

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $currentPassword = $_POST['current_password'] ?? '';
    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    if ($newPassword !== $confirmPassword) {
        $error = 'New password and confirmation do not match.';
    } elseif (strlen($newPassword) < 8) {
        $error = 'New password must be at least 8 characters.';
    } else {
        try {
            // Fetch current admin
            $stmt = $pdo->prepare('SELECT id, password FROM admin WHERE id = ?');
            $stmt->execute([$_SESSION['admin_id']]);
            $admin = $stmt->fetch();

            if (!$admin || !password_verify($currentPassword, $admin['password'])) {
                $error = 'Current password is incorrect.';
            } else {
                $hashed = password_hash($newPassword, PASSWORD_BCRYPT);
                $upd = $pdo->prepare('UPDATE admin SET password = ? WHERE id = ?');
                $upd->execute([$hashed, $admin['id']]);
                $success = 'Password updated successfully.';
            }
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password - Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .admin-change-password { min-height: 100vh; background: #f5f5f5; }
        .admin-header { background: #fff; padding: 1rem 0; box-shadow: 0 2px 10px rgba(0,0,0,.1); }
        .admin-nav { display: flex; justify-content: space-between; align-items: center; }
        .admin-nav a { color: #333; text-decoration: none; padding: .5rem 1rem; border-radius: 5px; }
        .admin-nav a:hover { background: #f5f5f5; }
        .form-card { background: #fff; max-width: 520px; margin: 2rem auto; padding: 1.5rem; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,.1); }
        .form-card h1 { margin-bottom: 1rem; font-size: 1.3rem; color: #333; }
        .form-group { margin-bottom: 1rem; }
        .form-group label { display: block; margin-bottom: .5rem; color: #333; }
        .form-group input { width: 100%; padding: 12px 15px; border: 2px solid #e0e0e0; border-radius: 8px; outline: none; transition: border-color .3s ease; }
        .form-group input:focus { border-color: #25D366; }
        .btn { display: inline-block; padding: .75rem 1.25rem; background: #25D366; color: #fff; border: none; border-radius: 8px; cursor: pointer; }
        .btn:hover { background: #128C7E; }
        .alert { padding: 1rem; border-radius: 8px; margin-bottom: 1rem; }
        .alert-success { background: #e8f5e9; color: #2e7d32; }
        .alert-error { background: #ffebee; color: #c62828; }
    </style>
</head>
<body>
    <div class="admin-change-password">
        <header class="admin-header">
            <div class="container">
                <nav class="admin-nav">
                    <h1><i class="fas fa-key"></i> Change Password</h1>
                    <div class="nav-links">
                        <a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
                        <a href="products.php"><i class="fas fa-box"></i> Products</a>
                        <a href="messages.php"><i class="fas fa-envelope"></i> Messages</a>
                        <a href="logout.php" class="logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
                    </div>
                </nav>
            </div>
        </header>

        <main class="container">
            <div class="form-card">
                <?php if (!empty($success)): ?>
                    <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
                <?php endif; ?>
                <?php if (!empty($error)): ?>
                    <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>
                <form method="POST">
                    <div class="form-group">
                        <label for="current_password">Current Password</label>
                        <input type="password" id="current_password" name="current_password" required>
                    </div>
                    <div class="form-group">
                        <label for="new_password">New Password</label>
                        <input type="password" id="new_password" name="new_password" minlength="8" required>
                    </div>
                    <div class="form-group">
                        <label for="confirm_password">Confirm New Password</label>
                        <input type="password" id="confirm_password" name="confirm_password" minlength="8" required>
                    </div>
                    <button type="submit" class="btn">Update Password</button>
                </form>
            </div>
        </main>
    </div>
</body>
</html>


